/**
 * Genesis OS Application: Polar Musical Language Model v1.2.1
 * This file encapsulates the HTML, CSS, and JS for the application.
 * FIX: Used window.parent.document in dialogs to access elements in the main OS document.
 */
export function initialize(gos) {
    const container = gos.window.getContainer();

    // Helper function to load external scripts dynamically
    const loadScript = (url) => {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = url;
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    };

    // --- 1. Define the CSS for the application ---
    const appCSS = `
        /* Vintage palette & fonts */
        @import url("https://fonts.googleapis.com/css2?family=Special+Elite&display=swap");
        :root {
            --bg: #f4ecd8;         /* parchment */
            --card: #fffdf6;       /* off-white card */
            --ink: #2f2f2f;        /* dark ink */
            --accent: #8b5e34;     /* brown leather */
            --shadow: 0 3px 6px rgba(0,0,0,0.08);
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            padding: 1.8rem;
            background: var(--bg);
            font-family: "Special Elite", Courier, monospace;
            color: var(--ink);
            display: flex;
            flex-direction: column;
            gap: 1.6rem;
            height: 100%;
            overflow-y: auto;
        }
        .gos-dialog-input {
             width: 100%;
             padding: 8px;
             font-family: inherit;
             font-size: 1rem;
             background: #faf7ee;
             border: 1px solid var(--ink);
             margin-top: 5px;
        }
        h1 { margin: 0; font-size: 1.85rem; letter-spacing: 0.03em; }
        .card {
            background: var(--card);
            border: 2px solid var(--ink);
            border-radius: 0.75rem;
            box-shadow: var(--shadow);
            padding: 1rem;
        }
        #seq-container { display: flex; flex-direction: column; gap: 1rem; max-width: 960px; width: 100%; }
        .seq-card textarea { width: 100%; min-height: 4rem; padding: 0.5rem; border: 1px solid var(--ink); background: #faf7ee; font-family: inherit; font-size: 0.95rem; }
        button, select {
            font-family: inherit;
            font-size: 0.95rem;
            background: var(--accent);
            color: #fff;
            border: none;
            padding: 0.45rem 1rem;
            border-radius: 0.4rem;
            cursor: pointer;
            transition: opacity .2s, background-color .2s;
        }
        button:hover:not(:disabled), select:hover { opacity: 0.83; }
        button:disabled { opacity: .45; cursor: not-allowed; background-color: #6c584c; }
        select {
            appearance: none; -webkit-appearance: none; position: relative; padding-right: 1.8rem;
            background-image: url('data:image/svg+xml;base64,PHN2ZyBmaWxsPSIjZmZmIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMCIgaGVpZ2h0PSI2Ij48cGF0aCBkPSJNMCwwbDEwLDBMMCw2WiIvPjwvc3ZnPg==');
            background-repeat: no-repeat; background-position: right 0.4rem center; background-size: 0.6rem;
        }
        .btn-row { display: flex; gap: 0.6rem; flex-wrap: wrap; align-items: center; }
        .chart-wrapper { display: none; height: 350px; max-width: 960px; width: 100%; }
        canvas { background: var(--card); border: 2px solid var(--ink); border-radius: 0.75rem; }
        table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
        th, td { border: 1px solid var(--ink); padding: 0.3rem 0.5rem; text-align: center; }
    `;

    // --- 2. Define the HTML structure ---
    const appHTML = `
        <h1>Polar Musical Language Model (Vintage Edition)</h1>
        <p class="card">Input numeric sequences, build a <strong>polar</strong> representation, <em>entangle</em> them into one melody, then export the entangled plot as an image with your chosen background colour.</p>

        <div id="seq-container"></div>

        <div class="btn-row card" style="gap:1rem;">
            <button id="add-seq">Add Sequence</button>
            <button id="gen-set">Generate Set</button>
            <button id="gen-polar">Generate Polar Model</button>
            <button id="entangle" disabled>Entangle</button>
            <button id="export-png" disabled>Export PNG</button>
            <button id="export-wav" disabled>Export WAV</button>

            <label style="display:flex;align-items:center;gap:0.4rem">Oscillator
                <select id="osc-type">
                    <option value="triangle">Triangle</option>
                    <option value="sine">Sine</option>
                    <option value="square">Square</option>
                    <option value="sawtooth">Sawtooth</option>
                </select>
            </label>

            <label style="display:flex;align-items:center;gap:0.4rem">Export BG
                <select id="bg-col">
                    <option value="#f4ecd8">Parchment</option>
                    <option value="#fafafa">White</option>
                    <option value="#000000">Black</option>
                    <option value="#182d4d">Indigo Night</option>
                </select>
            </label>
        </div>

        <div id="chart-polar" class="chart-wrapper"><canvas id="polar-chart"></canvas></div>
        <div id="distances" class="card" style="display:none"></div>
    `;

    // --- 3. Inject CSS and HTML into the GOS container ---
    container.innerHTML = `<style>${appCSS}</style>${appHTML}`;

    // --- 4. Main Application Logic ---
    const runAppLogic = () => {
        // === DOM (scoped to the container) ===
        const seqC = container.querySelector('#seq-container');
        const addB = container.querySelector('#add-seq');
        const genSetB = container.querySelector('#gen-set');
        const genB = container.querySelector('#gen-polar');
        const entB = container.querySelector('#entangle');
        const expPngB = container.querySelector('#export-png');
        const expWavB = container.querySelector('#export-wav');
        const oscSel = container.querySelector('#osc-type');
        const bgSel = container.querySelector('#bg-col');
        const chartWrap = container.querySelector('#chart-polar');
        const distDiv = container.querySelector('#distances');
        let chart = null, seqN = 0, imgs = [], entangled = null, entPlot = false;

        // === Data structures & Audio Utils ===
        class Seq { constructor(label, v) { this.label = label; this.v = v } }
        class Functor {
            constructor(lo = 48, hi = 72) { this.lo = lo; this.hi = hi }
            map(s) { const a = Math.min(...s.v), b = Math.max(...s.v), d = b - a || 1; return s.v.map(x => this.lo + ((x - a) / d) * (this.hi - this.lo)) }
        }
        function bufferToWave(buffer) { const numOfChan = buffer.numberOfChannels, length = buffer.length * numOfChan * 2 + 44, abuffer = new ArrayBuffer(length), view = new DataView(abuffer), channels = []; let pos = 0; const setUint16 = (data) => { view.setUint16(pos, data, true); pos += 2; }; const setUint32 = (data) => { view.setUint32(pos, data, true); pos += 4; }; setUint32(0x46464952); setUint32(length - 8); setUint32(0x45564157); setUint32(0x20746d66); setUint32(16); setUint16(1); setUint16(numOfChan); setUint32(buffer.sampleRate); setUint32(buffer.sampleRate * 2 * numOfChan); setUint16(numOfChan * 2); setUint16(16); setUint32(0x61746164); setUint32(length - pos - 4); for (let i = 0; i < numOfChan; i++) { channels.push(buffer.getChannelData(i)); } for (let i = 0; i < buffer.length; i++) { for (let j = 0; j < numOfChan; j++) { const sample = Math.max(-1, Math.min(1, channels[j][i])); view.setInt16(pos, sample < 0 ? sample * 32768 : sample * 32767, true); pos += 2; } } return new Blob([view], { type: "audio/wav" }); }
        
        // === Core Functions ===
        function addCard(init = '') { seqN++; const c = document.createElement('div'); c.className = 'seq-card card'; c.innerHTML = `<label>Seq ${seqN}</label><textarea>${init}</textarea><button class="play" disabled>▶ Play</button>`; seqC.appendChild(c); }
        function parse() { return [...container.querySelectorAll('.seq-card')].map((el, i) => { const t = el.querySelector('textarea').value.trim(); if (!t) return null; const v = t.split(/[\s,]+/).map(Number).filter(n => !isNaN(n)); return v.length ? new Seq('S' + (i + 1), v) : null }).filter(Boolean) }
        function mapAll(ss) { return ss.map(s => new Functor().map(s)) }
        function play(arr) { const synth = new Tone.Synth({ oscillator: { type: oscSel.value } }).toDestination(); const t = Tone.now(); arr.forEach((m, i) => synth.triggerAttackRelease(Tone.Frequency(m, 'midi'), '8n', t + i * 0.3)) }
        function linkPlay(ss, im) { const cards = [...container.querySelectorAll('.seq-card')]; ss.forEach((s, i) => { const b = cards[i].querySelector('.play'); b.disabled = false; b.onclick = () => play(im[i]) }) }
        function dist(ss, im) { const n = ss.length, m = Array.from({ length: n }, () => Array(n).fill('–')); for (let i = 0; i < n; i++) { for (let j = i + 1; j < n; j++) { const len = Math.min(im[i].length, im[j].length); let sum = 0; for (let k = 0; k < len; k++) { const d = Math.log(im[j][k] / im[i][k]); sum += d * d } m[i][j] = m[j][i] = Math.sqrt(sum / len).toFixed(3) } } let h = '<h2>Distance Matrix</h2><table><thead><tr><th></th>' + ss.map(s => `<th>${s.label}</th>`).join('') + '</tr></thead><tbody>'; ss.forEach((s, i) => { h += '<tr><th>' + s.label + '</th>' + m[i].map(v => '<td>' + v + '</td>').join('') + '</tr>' }); h += '</tbody></table>'; distDiv.innerHTML = h; distDiv.style.display = 'block' }
        function avg(im) { const L = Math.max(...im.map(a => a.length)); return Array.from({ length: L }, (_, i) => { let s = 0, c = 0; im.forEach(seq => { if (i < seq.length) { s += seq[i]; c++ } }); return s / c }) }
        function buildChart(labels, datasets) { const ctx = container.querySelector('#polar-chart').getContext('2d'); if (chart) chart.destroy(); chart = new Chart(ctx, { type: 'radar', data: { labels, datasets }, options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, elements: { line: { tension: 0.4 } }, scales: { r: { angleLines: { display: false }, min: 40, max: 80 } } } }); chartWrap.style.display = 'block' }

        // === Main Action Handlers ===
        function gen() { const ss = parse(); if (ss.length < 2) { gos.ui.showNotification("Error", "Please enter at least two valid sequences."); return; } imgs = mapAll(ss); linkPlay(ss, imgs); dist(ss, imgs); const max = Math.max(...imgs.map(a => a.length)); const labels = Array.from({ length: max }, (_, i) => 'θ' + (i + 1)); const cols = ['#a34f3d', '#406882', '#2ca02c', '#d4a659', '#7b3f00', '#c85c5c']; const ds = imgs.map((d, i) => ({ label: ss[i].label, data: d, borderColor: cols[i % cols.length], backgroundColor: 'rgba(0,0,0,0)', fill: false, pointRadius: 3, tension: 0.4 })); buildChart(labels, ds); entB.disabled = false; expPngB.disabled = true; expWavB.disabled = true; entPlot = false; }
        function ent() { if (!imgs.length) return; entangled = avg(imgs); play(entangled); if (!entPlot) { chart.data.datasets.push({ label: 'Entangled', data: entangled, borderColor: '#000', borderWidth: 3, fill: false, pointRadius: 0, tension: 0.4 }); chart.update(); entPlot = true } expPngB.disabled = false; expWavB.disabled = false; }
        function exportPNG() { if (!entPlot) return; const bg = bgSel.value; const offscreenCanvas = document.createElement('canvas'); offscreenCanvas.width = 600; offscreenCanvas.height = 600; const offCtx = offscreenCanvas.getContext('2d'); const L = entangled.length; const lbls = Array.from({ length: L }, (_, i) => 'θ' + (i + 1)); const tempChart = new Chart(offCtx, { type: 'radar', data: { labels: lbls, datasets: [{ label: 'Entangled', data: entangled, borderColor: '#000', borderWidth: 3, pointRadius: 0, fill: false, tension: 0.4 }] }, options: { animation: false, responsive: false, plugins: { legend: { display: false } }, scales: { r: { angleLines: { display: false }, min: 40, max: 80 } } } }); setTimeout(() => { offCtx.globalCompositeOperation = 'destination-over'; offCtx.fillStyle = bg; offCtx.fillRect(0, 0, offscreenCanvas.width, offscreenCanvas.height); const url = offscreenCanvas.toDataURL('image/png'); const a = document.createElement('a'); a.href = url; a.download = 'entangled_polar.png'; container.appendChild(a); a.click(); a.remove(); tempChart.destroy(); }, 250); }

        async function generateSet() {
            // --- Dialog 1: Get starting sequence ---
            const res1 = await gos.ui.showDialog('Generate Set (1/3)',
                `<div><label for="start_seq">Enter starting sequence (e.g., 1,2,3,4):</label><input type="text" id="start_seq" value="1,3,5,7" class="gos-dialog-input"></div>`,
                { buttons: ['Cancel', 'Next'], getFormData: () => ({ val: window.parent.document.getElementById('start_seq').value }) }
            );
            if (res1.button !== 'Next' || !res1.formData.val) return;
            const startSeqStr = res1.formData.val;
            
            // --- Dialog 2: Get number of sequences ---
            const res2 = await gos.ui.showDialog('Generate Set (2/3)',
                `<div><label for="num_gen">How many sequences to generate?</label><input type="number" id="num_gen" value="5" class="gos-dialog-input"></div>`,
                { buttons: ['Cancel', 'Next'], getFormData: () => ({ val: window.parent.document.getElementById('num_gen').value }) }
            );
            if (res2.button !== 'Next' || !res2.formData.val) return;
            const numToGen = parseInt(res2.formData.val);
            if (isNaN(numToGen) || numToGen < 1) return;

            // --- Dialog 3: Get step increment ---
            const res3 = await gos.ui.showDialog('Generate Set (3/3)',
                `<div><label for="step_inc">What is the step increment for each number?</label><input type="number" id="step_inc" value="1" class="gos-dialog-input"></div>`,
                { buttons: ['Cancel', 'Generate'], getFormData: () => ({ val: window.parent.document.getElementById('step_inc').value }) }
            );
            if (res3.button !== 'Generate' || !res3.formData.val) return;
            const step = parseInt(res3.formData.val);
            if (isNaN(step)) return;

            // --- Process the collected data ---
            let currentSeq = startSeqStr.split(/[\s,]+/).map(Number).filter(n => !isNaN(n));
            if (!currentSeq.length) { gos.ui.showNotification("Error", "Invalid starting sequence."); return; }

            seqC.innerHTML = '';
            seqN = 0;
            for (let i = 0; i < numToGen; i++) {
                addCard(currentSeq.join(','));
                currentSeq = currentSeq.map(n => n + step);
            }
        }
        
        async function exportWAV() {
            if (!entangled || !entangled.length) { gos.ui.showNotification("Error", "Please entangle a sequence first."); return; }
            gos.ui.showNotification("Rendering...", "Exporting audio to WAV file, please wait.", 4000);
            expWavB.disabled = true; expWavB.textContent = "Rendering...";
            try {
                const duration = entangled.length * 0.3 + 0.5;
                const buffer = await Tone.Offline(({ transport }) => {
                    const synth = new Tone.Synth({ oscillator: { type: oscSel.value } }).toDestination();
                    entangled.forEach((m, i) => { synth.triggerAttackRelease(Tone.Frequency(m, "midi"), "8n", i * 0.3); });
                }, duration);
                const blob = bufferToWave(buffer);
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a'); a.href = url; a.download = 'entangled_melody.wav';
                container.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
            } catch (error) { console.error("WAV Export failed:", error); gos.ui.showNotification("Error", "Failed to export WAV file.", 5000); } finally { expWavB.disabled = false; expWavB.textContent = "Export WAV"; }
        }

        // === Event Listener Setup ===
        addCard('1,3,5,7,11,13'); addCard('2 4 6 8 10 12');
        addB.onclick = () => addCard();
        genSetB.onclick = generateSet;
        genB.onclick = gen;
        entB.onclick = ent;
        expPngB.onclick = exportPNG;
        expWavB.onclick = exportWAV;
    };

    // --- 5. Load external scripts and then run the app logic ---
    Promise.all([
        loadScript("https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.39/Tone.min.js"),
        loadScript("https://cdn.jsdelivr.net/npm/chart.js")
    ]).then(() => {
        runAppLogic();
    }).catch(err => {
        console.error("Failed to load external libraries for Polar Music app:", err);
        container.innerHTML = `<div style="padding:20px;color:red;">Error: Could not load required libraries (Tone.js, Chart.js). Please check your internet connection.</div>`;
    });
}
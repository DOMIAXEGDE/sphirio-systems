export function initialize(gosApiProxy) {
    const container = gosApiProxy.window.getContainer();
    const doc = container.ownerDocument; // Use the iframe's document object

    /**
     * Dynamically loads an external script into the sandboxed environment.
     * @param {string} url - The URL of the script to load.
     * @returns {Promise<void>} A promise that resolves when the script is loaded.
     */
    function loadScript(url) {
        return new Promise((resolve, reject) => {
            const script = doc.createElement('script');
            script.src = url;
            script.onload = resolve;
            script.onerror = () => reject(new Error(`Failed to load script: ${url}`));
            doc.head.appendChild(script);
        });
    }
	
    /**
     * ✅ FIXED: A more robust function to convert rgb() or rgba() color strings to #RRGGBB hex.
     * @param {string} rgbString - The RGB or RGBA color string.
     * @returns {string} The color in hexadecimal format.
     */
    function rgbToHex(rgbString) {
        if (!rgbString || typeof rgbString !== 'string') return '#ffffff';
        if (rgbString.startsWith('#')) return rgbString;

        const match = rgbString.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*[\d.]+)?\)$/);
        if (!match) return '#ffffff'; // Default for non-matching formats (e.g., 'transparent')

        const toHex = c => ('0' + parseInt(c, 10).toString(16)).slice(-2);
        
        return `#${toHex(match[1])}${toHex(match[2])}${toHex(match[3])}`;
    }

    /**
     * The main function to set up and run the application.
     */
    async function main() {
        try {
            // Load required external libraries. html2canvas is essential for the export feature.
            await loadScript("https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js");

            // --- 1. Inject CSS Styles ---
            const style = doc.createElement('style');
            style.textContent = `
                /* General Layout & Theming */
                :root {
                    --primary-color: #4B5320; /* Army Green */
                    --secondary-color: #BDB76B; /* Dark Khaki */
                    --background-color: #F5F5DC; /* Beige */
                    --text-color: #333333; /* Dark Gray */
                    --font-main: "Fira Code", "Consolas", monospace;
                }
                body {
                    font-family: var(--font-main);
                    background-color: var(--background-color);
                    color: var(--text-color);
                    margin: 0;
                    padding: 20px;
                    height: 100%;
                    box-sizing: border-box;
                }
                header { text-align: center; margin-bottom: 20px; color: var(--primary-color); }
                .operation-section { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); max-width: 1200px; margin: auto; }
                .operation-container { display: flex; gap: 20px; flex-wrap: wrap; }
                .operation-controls { flex: 1; min-width: 250px; }
                .operation-result { flex: 2; min-width: 400px; }
                h1, h2, h3 { color: var(--primary-color); }
                h2 { margin-top: 0; border-bottom: 2px solid var(--background-color); padding-bottom: 10px; }
                .form-group { margin-bottom: 15px; }
                label { display: block; margin-bottom: 5px; font-weight: bold; }
                input[type="number"] { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
                .control-row { display: flex; gap: 10px; margin-top: 20px; }
                button { padding: 10px 15px; border: none; border-radius: 4px; background-color: var(--primary-color); color: white; cursor: pointer; font-family: var(--font-main); transition: background-color 0.3s; }
                button:hover { background-color: #3a411a; }
                #quadtree-container { position: relative; border: 2px solid var(--secondary-color); background-color: #f9f9f9; margin: auto; }
                .quadtree-cell { position: absolute; box-sizing: border-box; border: 1px solid #ccc; }
                .cell-content { display: flex; justify-content: center; align-items: center; width: 100%; height: 100%; font-size: 12px; color: #555; user-select: none; }
                .quadtree-cell.can-subdivide { cursor: pointer; }
                .quadtree-cell.can-subdivide:hover { background-color: rgba(0, 0, 0, 0.05); }
                .quadtree-context-menu { position: absolute; background-color: white; border: 1px solid var(--secondary-color); border-radius: 4px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); padding: 8px 0; min-width: 200px; z-index: 1000; display: none; }
                .quadtree-context-menu.active { display: block; }
                .context-menu-item { padding: 8px 16px; cursor: pointer; transition: background-color 0.2s ease; display: flex; align-items: center; user-select: none; }
                .context-menu-item:hover { background-color: var(--background-color); }
                .context-menu-item-icon { margin-right: 10px; width: 16px; text-align: center; }
                .context-menu-separator { height: 1px; background-color: var(--secondary-color); margin: 6px 0; opacity: 0.3; }
                .quadtree-cell-custom-text { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 90%; font-family: var(--font-main); pointer-events: none; }
                .quadtree-cell-image { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; pointer-events: none; }
                .quadtree-cell.customized .cell-content { display: none; }
                .quadtree-cell.paste-focus { outline: 2px dashed var(--primary-color); z-index: 10; }
                .paste-indicator { position: fixed; bottom: 20px; right: 20px; background-color: var(--background-color); border: 1px solid var(--secondary-color); border-left: 4px solid var(--primary-color); padding: 10px 15px; font-size: 0.9rem; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 4px; z-index: 1000; display: none; }
                .paste-indicator.active { display: block; animation: fadeIn 0.3s ease-in-out; }
                .export-loading { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); display: none; justify-content: center; align-items: center; z-index: 2000; }
                .export-loading.active { display: flex; }
                .export-loading-content { background-color: white; padding: 20px; border-radius: 4px; text-align: center; }
                .export-spinner { border: 4px solid #f3f3f3; border-top: 4px solid var(--primary-color); border-radius: 50%; width: 40px; height: 40px; animation: spin 2s linear infinite; margin: 0 auto 15px auto; }
                @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                .quadtree-modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); display: none; justify-content: center; align-items: center; z-index: 1100; }
                .quadtree-modal.active { display: flex; }
                .quadtree-modal-content { background-color: white; padding: 20px; border-radius: 4px; max-width: 400px; width: 90%; }
                .quadtree-modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
                .quadtree-modal-header h3 { margin: 0; }
                .quadtree-modal-close { background: none; border: none; font-size: 1.5rem; cursor: pointer; padding: 0; color: var(--text-color); }
                .quadtree-modal-body { margin-bottom: 20px; }
                .quadtree-form-actions { display: flex; justify-content: flex-end; gap: 10px; }
                .button-secondary { background-color: #6c757d; }
                .button-secondary:hover { background-color: #5a6268; }
            `;
            doc.head.appendChild(style);

            // --- 2. Inject HTML Structure ---
            container.innerHTML = `
                <header>
                    <h1>Quadtree Operations</h1>
                </header>
                <main>
                    <section id="tree-operations" class="operation-section">
                        <div class="operation-container">
                            <div class="operation-controls">
                                <h2>Quadtree Settings</h2>
                                <div class="form-group">
                                    <label for="max-depth">Max Depth:</label>
                                    <input type="number" id="max-depth" min="1" max="6" value="3">
                                </div>
                                <div class="form-group">
                                    <label for="quadtree-size">Size (px):</label>
                                    <input type="number" id="quadtree-size" min="200" max="800" value="400">
                                </div>
                                <div class="control-row">
                                    <button id="create-quadtree">Create</button>
                                    <button id="reset-quadtree">Reset</button>
                                    <button id="export-quadtree">Export PNG</button>
                                </div>
                            </div>
                            <div class="operation-result">
                                <h2>Result</h2>
                                <div id="quadtree-container"></div>
                            </div>
                        </div>
                    </section>
                </main>
                <input type="file" id="quadtree-image-input" accept="image/*" style="display:none;">
            `;

            // --- 3. Application Logic ---
            const maxDepthInput = doc.getElementById('max-depth');
            const quadtreeSizeInput = doc.getElementById('quadtree-size');
            const createQuadtreeBtn = doc.getElementById('create-quadtree');
            const resetQuadtreeBtn = doc.getElementById('reset-quadtree');
            const exportQuadtreeBtn = doc.getElementById('export-quadtree');
            const quadtreeContainer = doc.getElementById('quadtree-container');
            const imageFileInput = doc.getElementById('quadtree-image-input');
            
            let quadtreeRoot = null;
            let maxDepth = 3;
            let quadtreeSize = 400;
            let activeQuadtreeCell = null;

            class QuadtreeNode {
                constructor(x, y, size, depth) {
                    this.x = x;
                    this.y = y;
                    this.size = size;
                    this.depth = depth;
                    this.children = [];
                    this.data = {};
                    this.element = this.createElement();
                    this.updateVisualState();
                }

                createElement() {
                    const cell = doc.createElement('div');
                    cell.className = 'quadtree-cell';
                    cell.style.left = `${this.x}px`;
                    cell.style.top = `${this.y}px`;
                    cell.style.width = `${this.size}px`;
                    cell.style.height = `${this.size}px`;

                    const content = doc.createElement('div');
                    content.className = 'cell-content';
                    content.textContent = `d: ${this.depth}`;
                    cell.appendChild(content);

                    cell.addEventListener('click', () => this.handleClick());
                    quadtreeContainer.appendChild(cell);
                    return cell;
                }

                updateVisualState() {
                    if (this.depth < maxDepth) {
                        this.element.classList.add('can-subdivide');
                        this.element.title = 'Click to subdivide';
                    } else {
                        this.element.classList.remove('can-subdivide');
                        this.element.title = 'Max depth reached';
                    }
                    const hue = (this.depth * 30) % 360;
                    this.element.style.backgroundColor = `hsl(${hue}, 70%, 90%)`;
                    this.element.style.borderColor = `hsl(${hue}, 70%, 60%)`;
                }

                handleClick() {
                    if (this.children.length === 0 && this.depth < maxDepth) {
                        this.subdivide();
                    }
                }

                subdivide() {
                    if (this.children.length > 0 || this.depth >= maxDepth) return false;
                    const childSize = this.size / 2;
                    this.children.push(
                        new QuadtreeNode(this.x, this.y, childSize, this.depth + 1),
                        new QuadtreeNode(this.x + childSize, this.y, childSize, this.depth + 1),
                        new QuadtreeNode(this.x, this.y + childSize, childSize, this.depth + 1),
                        new QuadtreeNode(this.x + childSize, this.y + childSize, childSize, this.depth + 1)
                    );
                    this.element.style.display = 'none';
                    return true;
                }
            }
            
            function initQuadtree() {
                quadtreeContainer.innerHTML = '';
                maxDepth = parseInt(maxDepthInput.value) || 3;
                quadtreeSize = parseInt(quadtreeSizeInput.value) || 400;
                quadtreeContainer.style.width = `${quadtreeSize}px`;
                quadtreeContainer.style.height = `${quadtreeSize}px`;
                quadtreeRoot = new QuadtreeNode(0, 0, quadtreeSize, 0);
            }

            function initExtensions() {
                quadtreeContainer.addEventListener('contextmenu', handleQuadtreeContextMenu);
                createContextMenu();
                setupClipboardPaste();
                imageFileInput.addEventListener('change', handleImageUpload);
            }

            function createContextMenu() {
                if (doc.getElementById('quadtree-context-menu')) return;
                
                const menu = doc.createElement('div');
                menu.id = 'quadtree-context-menu';
                menu.className = 'quadtree-context-menu';
                menu.innerHTML = `
                    <div class="context-menu-item" data-action="change-color"><span class="context-menu-item-icon">🎨</span><span>Change Color...</span></div>
                    <div class="context-menu-item" data-action="add-text"><span class="context-menu-item-icon">T</span><span>Add Text...</span></div>
                    <div class="context-menu-item" data-action="add-image"><span class="context-menu-item-icon">🖼️</span><span>Add Image...</span></div>
                    <div class="context-menu-item" data-action="paste-image"><span class="context-menu-item-icon">📋</span><span>Paste From Clipboard</span></div>
                    <div class="context-menu-separator"></div>
                    <div class="context-menu-item" data-action="reset-cell"><span class="context-menu-item-icon">↩️</span><span>Reset Cell</span></div>
                `;
                doc.body.appendChild(menu);

                menu.querySelectorAll('.context-menu-item').forEach(item => {
                    item.addEventListener('click', handleContextMenuAction);
                });

                doc.addEventListener('click', (e) => {
                    if (!menu.contains(e.target)) menu.classList.remove('active');
                });

                const pasteIndicator = doc.createElement('div');
                pasteIndicator.id = 'paste-indicator';
                pasteIndicator.className = 'paste-indicator';
                pasteIndicator.textContent = 'Press Ctrl+V to paste image';
                doc.body.appendChild(pasteIndicator);
            }
            
            function handleQuadtreeContextMenu(event) {
                event.preventDefault();
                const cell = event.target.closest('.quadtree-cell');
                if (!cell) return;
                
                activeQuadtreeCell = cell;
                const menu = doc.getElementById('quadtree-context-menu');
                menu.style.left = `${event.clientX}px`;
                menu.style.top = `${event.clientY}px`;
                menu.classList.add('active');
            }

            function handleContextMenuAction(event) {
                const action = event.currentTarget.getAttribute('data-action');
                const cell = activeQuadtreeCell;
                doc.getElementById('quadtree-context-menu').classList.remove('active');
                if (!cell) return;

                switch (action) {
                    case 'change-color': showColorPickerModal(cell); break;
                    case 'add-text': showTextModal(cell); break;
                    case 'add-image': imageFileInput.click(); break;
                    case 'paste-image': prepareCellForPaste(cell); break;
                    case 'reset-cell': resetCell(cell); break;
                }
            }

            function markCellAsCustomized(cell) {
                cell.classList.add('customized');
            }

            function showModal(id, content) {
                let modal = doc.getElementById(id);
                if (!modal) {
                    modal = doc.createElement('div');
                    modal.id = id;
                    modal.className = 'quadtree-modal';
                    doc.body.appendChild(modal);
                }
                modal.innerHTML = content;
                modal.classList.add('active');
                return modal;
            }

            function showColorPickerModal(cell) {
                // ✅ FIXED: Use the robust converter function here.
                const initialColorRgb = getComputedStyle(cell).backgroundColor;
                const initialColorHex = rgbToHex(initialColorRgb);
                const modalContent = `
                    <div class="quadtree-modal-content">
                        <div class="quadtree-modal-header"><h3>Change Cell Color</h3><button class="quadtree-modal-close">&times;</button></div>
                        <div class="quadtree-modal-body">
                            <div class="form-group"><label for="cell-color">Select Color:</label><input type="color" id="cell-color" value="${getComputedStyle(cell).backgroundColor || '#f0f0f0'}"></div>
                        </div>
                        <div class="quadtree-form-actions"><button class="button-secondary modal-cancel">Cancel</button><button class="modal-apply">Apply</button></div>
                    </div>`;
                const modal = showModal('color-picker-modal', modalContent);

                modal.querySelector('.modal-apply').onclick = () => {
                    cell.style.backgroundColor = doc.getElementById('cell-color').value;
                    markCellAsCustomized(cell);
                    modal.classList.remove('active');
                };
                modal.querySelector('.modal-cancel').onclick = () => modal.classList.remove('active');
                modal.querySelector('.quadtree-modal-close').onclick = () => modal.classList.remove('active');
            }

            function showTextModal(cell) {
                const existingText = cell.querySelector('.quadtree-cell-custom-text')?.textContent || '';
                const modalContent = `
                    <div class="quadtree-modal-content">
                        <div class="quadtree-modal-header"><h3>Add Text to Cell</h3><button class="quadtree-modal-close">&times;</button></div>
                        <div class="quadtree-modal-body">
                            <div class="form-group"><label for="cell-text">Text:</label><input type="text" id="cell-text" value="${existingText}"></div>
                            <div class="form-group"><label for="text-color">Text Color:</label><input type="color" id="text-color" value="#000000"></div>
                        </div>
                        <div class="quadtree-form-actions"><button class="button-secondary modal-cancel">Cancel</button><button class="modal-apply">Apply</button></div>
                    </div>`;
                const modal = showModal('text-modal', modalContent);
                
                modal.querySelector('.modal-apply').onclick = () => {
                    const text = doc.getElementById('cell-text').value;
                    const color = doc.getElementById('text-color').value;
                    let textElement = cell.querySelector('.quadtree-cell-custom-text');

                    if (text.trim() !== '') {
                        if (!textElement) {
                            textElement = doc.createElement('div');
                            textElement.className = 'quadtree-cell-custom-text';
                            cell.appendChild(textElement);
                        }
                        textElement.textContent = text;
                        textElement.style.color = color;
                        markCellAsCustomized(cell);
                    } else if (textElement) {
                        cell.removeChild(textElement);
                    }
                    modal.classList.remove('active');
                };
                modal.querySelector('.modal-cancel').onclick = () => modal.classList.remove('active');
                modal.querySelector('.quadtree-modal-close').onclick = () => modal.classList.remove('active');
            }

            function handleImageUpload(event) {
                const cell = activeQuadtreeCell;
                if (!cell || !event.target.files || !event.target.files[0]) return;
                const file = event.target.files[0];
                if (!file.type.startsWith('image/')) return;

                const reader = new FileReader();
                reader.onload = (e) => addImageToCell(cell, e.target.result);
                reader.readAsDataURL(file);
                event.target.value = '';
            }

            function addImageToCell(cell, imageDataUrl) {
                let img = cell.querySelector('.quadtree-cell-image');
                if (!img) {
                    img = doc.createElement('img');
                    img.className = 'quadtree-cell-image';
                    cell.appendChild(img);
                }
                img.src = imageDataUrl;
                markCellAsCustomized(cell);
            }

            function resetCell(cell) {
                const textElement = cell.querySelector('.quadtree-cell-custom-text');
                if (textElement) cell.removeChild(textElement);
                const imageElement = cell.querySelector('.quadtree-cell-image');
                if (imageElement) cell.removeChild(imageElement);
                cell.style.backgroundColor = '';
                cell.classList.remove('customized', 'paste-focus');
            }

            function prepareCellForPaste(cell) {
                doc.querySelector('.quadtree-cell.paste-focus')?.classList.remove('paste-focus');
                cell.classList.add('paste-focus');
                const indicator = doc.getElementById('paste-indicator');
                indicator.classList.add('active');
                setTimeout(() => indicator.classList.remove('active'), 3000);
            }

            function setupClipboardPaste() {
                doc.addEventListener('paste', (event) => {
                    const cell = doc.querySelector('.quadtree-cell.paste-focus');
                    if (!cell) return;
                    const items = (event.clipboardData || event.originalEvent.clipboardData).items;
                    for (const item of items) {
                        if (item.type.indexOf('image') === 0) {
                            const blob = item.getAsFile();
                            const reader = new FileReader();
                            reader.onload = (e) => {
                                addImageToCell(cell, e.target.result);
                                cell.classList.remove('paste-focus');
                                doc.getElementById('paste-indicator').classList.remove('active');
                            };
                            reader.readAsDataURL(blob);
                            event.preventDefault();
                            return;
                        }
                    }
                });
            }

            function exportEnhancedPNG() {
                showLoadingIndicator('Generating PNG...');
                if (typeof html2canvas === 'function') {
                    html2canvas(quadtreeContainer, {
                        scale: 2,
                        backgroundColor: null,
                        logging: false,
                        useCORS: true,
                        allowTaint: true
                    }).then(canvas => {
                        finishExport(canvas);
                    }).catch(error => {
                        console.error('html2canvas failed:', error);
                        gosApiProxy.ui.showNotification('Error', 'Failed to export quadtree: ' + error.message, 5000);
                        hideLoadingIndicator();
                    });
                } else {
                    gosApiProxy.ui.showNotification('Error', 'Export library not found.', 5000);
                    hideLoadingIndicator();
                }
            }
            
            function finishExport(canvas) {
                try {
                    const dataUrl = canvas.toDataURL('image/png');
                    const link = doc.createElement('a');
                    link.download = 'quadtree_export.png';
                    link.href = dataUrl;
                    link.click();
                } catch (error) {
                    console.error('Error generating PNG:', error);
                    gosApiProxy.ui.showNotification('Error', 'Failed to generate PNG: ' + error.message, 5000);
                } finally {
                    hideLoadingIndicator();
                }
            }
            
            function showLoadingIndicator(message) {
                let loadingEl = doc.getElementById('export-loading');
                if (!loadingEl) {
                    loadingEl = doc.createElement('div');
                    loadingEl.id = 'export-loading';
                    loadingEl.className = 'export-loading';
                    loadingEl.innerHTML = `
                        <div class="export-loading-content">
                            <div class="export-spinner"></div>
                            <div>${message}</div>
                        </div>`;
                    doc.body.appendChild(loadingEl);
                }
                loadingEl.classList.add('active');
            }
            
            function hideLoadingIndicator() {
                doc.getElementById('export-loading')?.classList.remove('active');
            }

            // --- INITIAL SETUP ---
            createQuadtreeBtn.addEventListener('click', initQuadtree);
            resetQuadtreeBtn.addEventListener('click', initQuadtree);
            exportQuadtreeBtn.addEventListener('click', exportEnhancedPNG);
            
            initQuadtree();
            initExtensions();

        } catch (error) {
            console.error("Failed to initialize Quadtree Visualizer:", error);
            container.innerHTML = `<div style="color: red; padding: 20px;">Error loading application resources: ${error.message}</div>`;
        }
    }

    // Run the main application setup.
    main();
}